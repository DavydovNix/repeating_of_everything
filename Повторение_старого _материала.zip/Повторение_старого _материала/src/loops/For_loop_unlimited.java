package loops;

public class For_loop_unlimited {
    //составить бесконечный цикл
    public static void main(String[] args) {
        for (;;){
            System.out.println("I am your nightmare");
        }
    }
}
